import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import {
  initialCompanyProfile,
  initialCustomers,
  initialSalesPersons,
  initialCareOfPersons,
  initialWorkers,
  initialDesigners,
  initialVendors,
  initialProducts,
  initialSalesOrders,
  initialInventory,
  initialPurchaseOrders,
  initialPayments,
  initialAttendance,
  initialPayroll,
  initialProductMaterialSpecs,
  initialEmployees,
  initialWorkerJobIncentives,
  initialOrderAuditLogs,
  initialMachines,
  initialWorkflows,
  initialProductionProcesses,
  initialProductionTasks
} from '../src/data/mockData.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const exportDir = __dirname;
const rootDir = path.join(__dirname, '..');
const dbPath = path.join(rootDir, 'database', 'erp.sqlite');

console.log('Connecting to database at:', dbPath);
const db = new Database(dbPath, { readonly: true });

// Helper: Escape CSV fields properly
function escapeCsv(val) {
  if (val === null || val === undefined) return '""';
  const str = String(val).replace(/"/g, '""');
  return `"${str}"`;
}

// Helper: Mask phone numbers for data privacy while keeping structure recognizable
function maskPhone(phone) {
  if (!phone) return '';
  const clean = String(phone).replace(/\s+/g, '');
  if (clean.length >= 10) {
    return clean.slice(0, 3) + 'XXXX' + clean.slice(-3);
  }
  return 'XXXXX' + clean.slice(-2);
}

// Helper: Mask email addresses for data privacy
function maskEmail(email) {
  if (!email || !email.includes('@')) return '';
  const [user, domain] = email.split('@');
  if (user.length <= 2) {
    return `${user[0]}***@${domain}`;
  }
  return `${user.slice(0, 2)}***${user.slice(-1)}@${domain}`;
}

// Helper: Write records to CSV
function writeCsv(filename, headers, records) {
  const filePath = path.join(exportDir, filename);
  const headerLine = headers.map(escapeCsv).join(',');
  const lines = [headerLine];

  for (const r of records) {
    const line = headers.map(h => escapeCsv(r[h] ?? '')).join(',');
    lines.push(line);
  }

  fs.writeFileSync(filePath, lines.join('\n'), 'utf8');
  console.log(`Exported ${filename}: ${records.length} rows`);
}

// 1. Inspect existing tables
const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all();
console.log(`Found ${tables.length} tables in SQLite:`);

const tableStats = {};
for (const t of tables) {
  const count = db.prepare(`SELECT COUNT(*) as count FROM ${t.name}`).get().count;
  const cols = db.prepare(`PRAGMA table_info(${t.name})`).all();
  tableStats[t.name] = { count, columns: cols.map(c => ({ name: c.name, type: c.type, notnull: c.notnull, dflt: c.dflt_value, pk: c.pk })) };
  console.log(`- ${t.name}: ${count} records, ${cols.length} columns`);
}
fs.writeFileSync(path.join(exportDir, 'raw_schema_stats.json'), JSON.stringify(tableStats, null, 2), 'utf8');

// ==========================================
// EXPORT SAFE CSVs
// ==========================================

// 1. Customers
const rawCustomers = db.prepare("SELECT * FROM customers ORDER BY created_at DESC").all();
const customers = rawCustomers.map(c => ({
  customer_id: c.id,
  customer_code: c.customer_code || '',
  name: c.name,
  mobile: maskPhone(c.mobile),
  additional_mobiles: c.additional_mobiles ? JSON.parse(c.additional_mobiles || '[]').map(maskPhone).join('; ') : '',
  email: maskEmail(c.email),
  address: (c.address || '').replace(/[\r\n]+/g, ' '),
  gstin: c.gst_number || '',
  customer_type: c.customer_type || 'Retail',
  credit_limit: c.credit_limit || 0,
  outstanding_balance: c.outstanding || 0,
  created_at: c.created_at || '',
  status: 'Active'
}));
writeCsv('customers.csv', [
  'customer_id', 'customer_code', 'name', 'mobile', 'additional_mobiles',
  'email', 'address', 'gstin', 'customer_type', 'credit_limit',
  'outstanding_balance', 'created_at', 'status'
], customers);

// 2. Products
const rawProducts = db.prepare("SELECT * FROM products ORDER BY name ASC").all();
const products = rawProducts.map(p => ({
  product_id: p.id,
  product_code: p.product_code || '',
  name: p.name,
  category: p.category || '',
  hsn_code: p.hsn_code || '9989',
  selling_rate: p.default_rate || 0,
  estimated_cost: p.estimated_cost || 0,
  unit: p.unit || 'Sq.Ft',
  gst_rate: p.gst_rate || 18,
  default_material: p.default_material || '',
  default_vendor: p.default_vendor || '',
  is_custom: p.is_custom ? 'YES' : 'NO',
  active: p.active ? 'Active' : 'Inactive',
  created_at: p.created_at || '',
  description: (p.description || '').replace(/[\r\n]+/g, ' ')
}));
writeCsv('products.csv', [
  'product_id', 'product_code', 'name', 'category', 'hsn_code',
  'selling_rate', 'estimated_cost', 'unit', 'gst_rate', 'default_material',
  'default_vendor', 'is_custom', 'active', 'created_at', 'description'
], products);

// 3. Materials & Stock
let rawMaterials = [];
const invCount = db.prepare("SELECT COUNT(*) as count FROM inventory").get().count;
if (invCount > 0) {
  rawMaterials = db.prepare("SELECT * FROM inventory ORDER BY name ASC").all();
} else {
  // Use product_specifications + initialInventory
  rawMaterials = initialInventory.map(i => ({
    id: i.id,
    name: i.name,
    category: i.category,
    current_stock: i.currentStock || i.stockQuantity || 100,
    unit: i.unit || 'Sq.Ft',
    reorder_level: i.reorderLevel || 20,
    unit_cost: i.unitCost || i.unitRate || 0
  }));
}

const materials = rawMaterials.map(m => ({
  material_id: m.id,
  name: m.name,
  category: m.category || '',
  unit: m.unit || '',
  stock_quantity: m.current_stock ?? m.stock_quantity ?? 0,
  min_reorder_level: m.reorder_level ?? m.min_reorder_level ?? 0,
  unit_rate: m.unit_cost ?? m.unit_rate ?? 0,
  stock_value: (((m.current_stock ?? m.stock_quantity ?? 0) * (m.unit_cost ?? m.unit_rate ?? 0))).toFixed(2),
  status: 'In Stock'
}));
writeCsv('materials.csv', [
  'material_id', 'name', 'category', 'unit', 'stock_quantity',
  'min_reorder_level', 'unit_rate', 'stock_value', 'status'
], materials);

writeCsv('stock.csv', [
  'material_id', 'name', 'category', 'unit', 'stock_quantity',
  'min_reorder_level', 'unit_rate', 'stock_value', 'status'
], materials);

// 4. Orders & Quotations
const rawOrders = db.prepare("SELECT * FROM sales_orders ORDER BY order_date DESC, id DESC").all();

// Quotations / Estimates
const quotations = rawOrders.filter(o => o.order_number?.startsWith('QT-') || o.id?.startsWith('QT-') || o.production_status === 'Quotation').map(q => ({
  quotation_id: q.id,
  quotation_number: q.order_number || q.id,
  customer_id: q.customer_id || '',
  customer_name: q.customer_name,
  order_date: q.order_date,
  due_date: q.due_date || '',
  subtotal: q.subtotal || 0,
  discount: q.discount || 0,
  tax_total: q.tax_total || 0,
  grand_total: q.grand_total || 0,
  sales_person_name: q.sales_person_name || '',
  care_of_name: q.care_of_name || '',
  billed_by_staff: q.billed_by_staff || q.sales_person_name || 'Admin User',
  billed_at: q.billed_at || '',
  status: q.production_status || 'Quotation',
  notes: (q.notes || '').replace(/[\r\n]+/g, ' ')
}));
writeCsv('quotations.csv', [
  'quotation_id', 'quotation_number', 'customer_id', 'customer_name', 'order_date',
  'due_date', 'subtotal', 'discount', 'tax_total', 'grand_total', 'sales_person_name',
  'care_of_name', 'billed_by_staff', 'billed_at', 'status', 'notes'
], quotations);

// Sales Orders
const orders = rawOrders.filter(o => !o.order_number?.startsWith('QT-') && !o.id?.startsWith('QT-') && o.production_status !== 'Quotation').map(o => ({
  order_id: o.id,
  order_number: o.order_number || o.id,
  customer_id: o.customer_id || '',
  customer_name: o.customer_name,
  order_date: o.order_date,
  due_date: o.due_date || '',
  production_status: o.production_status || 'New',
  payment_status: o.payment_status || 'Pending',
  subtotal: o.subtotal || 0,
  discount: o.discount || 0,
  tax_total: o.tax_total || 0,
  grand_total: o.grand_total || 0,
  advance_amount: o.advance_amount || 0,
  balance_amount: o.balance_amount || 0,
  billed_by_staff: o.billed_by_staff || 'Staff',
  billed_by_role: o.billed_by_role || 'Sales',
  billed_at: o.billed_at || o.order_date || '',
  sales_person_name: o.sales_person_name || '',
  care_of_name: o.care_of_name || '',
  delivered_by: o.delivered_by || '',
  notes: (o.notes || '').replace(/[\r\n]+/g, ' ')
}));
writeCsv('orders.csv', [
  'order_id', 'order_number', 'customer_id', 'customer_name', 'order_date', 'due_date',
  'production_status', 'payment_status', 'subtotal', 'discount', 'tax_total',
  'grand_total', 'advance_amount', 'balance_amount', 'billed_by_staff', 'billed_by_role',
  'billed_at', 'sales_person_name', 'care_of_name', 'delivered_by', 'notes'
], orders);

// 5. Invoices
const invoices = orders.map((o) => ({
  invoice_number: `INV-${o.order_number}`,
  order_id: o.order_id,
  customer_id: o.customer_id,
  customer_name: o.customer_name,
  invoice_date: o.order_date,
  taxable_amount: o.subtotal,
  cgst: (Number(o.tax_total) / 2).toFixed(2),
  sgst: (Number(o.tax_total) / 2).toFixed(2),
  igst: '0.00',
  discount: o.discount,
  grand_total: o.grand_total,
  advance_paid: o.advance_amount,
  balance_due: o.balance_amount,
  payment_status: o.payment_status,
  billed_by: o.billed_by_staff
}));
writeCsv('invoices.csv', [
  'invoice_number', 'order_id', 'customer_id', 'customer_name', 'invoice_date',
  'taxable_amount', 'cgst', 'sgst', 'igst', 'discount', 'grand_total',
  'advance_paid', 'balance_due', 'payment_status', 'billed_by'
], invoices);

// 6. Order Items
const rawItems = db.prepare("SELECT * FROM sales_order_items ORDER BY sales_order_id, id").all();
const orderItems = rawItems.map(i => ({
  item_id: i.id,
  sales_order_id: i.sales_order_id,
  product_name: i.product_name_snapshot,
  job_card_id: i.job_card_id || '',
  custom_title: i.custom_title || '',
  material: i.material || '',
  width: i.width || '',
  height: i.height || '',
  qty: i.qty || 1,
  unit: i.unit || '',
  selling_rate: i.selling_rate || 0,
  taxable_amount: i.amount || 0,
  gst_rate: i.gst_rate || 18,
  estimated_cost: i.estimated_cost || 0,
  actual_cost: i.actual_cost || 0,
  outsource: i.outsource ? 'YES' : 'NO',
  vendor_name: i.vendor_name || '',
  designer_name: i.designer_name || '',
  printer_name: i.printer_name || '',
  finisher_name: i.finisher_name || '',
  production_status: i.production_status || 'New'
}));
writeCsv('order_items.csv', [
  'item_id', 'sales_order_id', 'product_name', 'job_card_id', 'custom_title',
  'material', 'width', 'height', 'qty', 'unit', 'selling_rate', 'taxable_amount',
  'gst_rate', 'estimated_cost', 'actual_cost', 'outsource', 'vendor_name',
  'designer_name', 'printer_name', 'finisher_name', 'production_status'
], orderItems);

// 7. Payments
const rawPayments = db.prepare("SELECT * FROM payments ORDER BY paid_date DESC").all();
const payments = rawPayments.map(p => ({
  payment_id: p.id,
  order_id: p.order_id || '',
  customer_id: p.customer_id || '',
  customer_name: p.customer_name || '',
  amount: p.amount || 0,
  payment_method: p.method || 'Cash',
  reference_number: p.ref_no || '',
  status: p.status || 'Completed',
  payment_date: p.paid_date || '',
  notes: (p.notes || '').replace(/[\r\n]+/g, ' ')
}));
writeCsv('payments.csv', [
  'payment_id', 'order_id', 'customer_id', 'customer_name', 'amount',
  'payment_method', 'reference_number', 'status', 'payment_date', 'notes'
], payments);

// 8. Employees (SAFE - No passwords)
const rawEmployees = db.prepare("SELECT * FROM employees ORDER BY id").all();
const employees = rawEmployees.map(e => ({
  employee_id: e.id,
  code: e.code || '',
  name: e.name,
  mobile: maskPhone(e.mobile),
  email: maskEmail(e.email),
  department: e.department || '',
  designation: e.designation || '',
  role: e.role || '',
  joined_date: e.joined_date || '',
  base_salary: e.base_salary || 0,
  incentive_rate: e.incentive_rate || 0,
  commission_rate: e.commission_rate || 0,
  status: e.status || (e.active ? 'Active' : 'Inactive')
}));
writeCsv('employees.csv', [
  'employee_id', 'code', 'name', 'mobile', 'email', 'department',
  'designation', 'role', 'joined_date', 'base_salary', 'incentive_rate',
  'commission_rate', 'status'
], employees);

// 9. Safe Users (Derived from employees and ERP roles with zero credentials)
const usersSafe = employees.map(e => ({
  user_id: `USR-${e.employee_id}`,
  employee_id: e.employee_id,
  employee_name: e.name,
  email: e.email,
  assigned_role: e.role || (e.department === 'Management' ? 'Admin' : e.department === 'Sales' ? 'Sales' : e.department === 'Design' ? 'Designer' : 'Production'),
  department: e.department,
  designation: e.designation || e.role,
  status: e.status,
  has_billing_access: (e.department === 'Sales' || e.department === 'Management' || e.role === 'Admin') ? 'YES' : 'NO',
  has_production_access: (e.department === 'Printing' || e.department === 'Production' || e.role === 'Production' || e.role === 'Admin') ? 'YES' : 'NO',
  has_design_access: (e.department === 'Design' || e.role === 'Designer' || e.role === 'Admin') ? 'YES' : 'NO',
  has_accounts_access: (e.department === 'Accounts' || e.role === 'Accounts' || e.role === 'Admin') ? 'YES' : 'NO'
}));
writeCsv('users_safe.csv', [
  'user_id', 'employee_id', 'employee_name', 'email', 'assigned_role',
  'department', 'designation', 'status', 'has_billing_access',
  'has_production_access', 'has_design_access', 'has_accounts_access'
], usersSafe);

// 10. Suppliers & Outsource Vendors
const rawSuppliers = db.prepare("SELECT * FROM suppliers ORDER BY id").all();
const suppliers = rawSuppliers.map(s => ({
  supplier_id: s.id,
  supplier_code: s.supplier_code || '',
  name: s.name,
  category: s.category || '',
  mobile: maskPhone(s.mobile),
  email: maskEmail(s.email),
  address: (s.address || '').replace(/[\r\n]+/g, ' '),
  gstin: s.gstin || '',
  pending_payment: s.pending_payment || 0,
  avg_turnaround_days: s.avg_turnaround_days || 2,
  status: s.active ? 'Active' : 'Inactive'
}));
writeCsv('suppliers.csv', [
  'supplier_id', 'supplier_code', 'name', 'category', 'mobile', 'email',
  'address', 'gstin', 'pending_payment', 'avg_turnaround_days', 'status'
], suppliers);

// 11. Purchases (From Outsource Jobs & Purchase Orders)
const rawOutsourceJobs = db.prepare("SELECT * FROM outsource_jobs ORDER BY created_at DESC").all();
const purchases = rawOutsourceJobs.map(j => ({
  purchase_id: j.id,
  outsource_number: j.outsource_number || '',
  order_id: j.sales_order_id || '',
  item_id: j.sales_order_item_id || '',
  supplier_id: j.supplier_id || '',
  supplier_name: j.supplier_name || '',
  work_description: (j.work_description || '').replace(/[\r\n]+/g, ' '),
  quantity: j.quantity || 1,
  outsource_cost: j.outsource_cost || 0,
  status: j.status || 'SENT',
  expected_date: j.expected_date || '',
  sent_date: j.sent_date || '',
  received_date: j.received_date || '',
  created_at: j.created_at || ''
}));
writeCsv('purchases.csv', [
  'purchase_id', 'outsource_number', 'order_id', 'item_id', 'supplier_id',
  'supplier_name', 'work_description', 'quantity', 'outsource_cost', 'status',
  'expected_date', 'sent_date', 'received_date', 'created_at'
], purchases);

// 12. Expenses (Derived from Outsource Costs & Initial Journal Vouchers)
const sampleExpenses = [
  { id: 'EXP-889', category: 'Raw Materials (Ink & Solvents)', amount: 17700, vendor_name: 'Sun Chemicals India', payment_method: 'Bank Transfer', expense_date: '2026-08-03', description: 'Solvent ink refill batch 4' },
  { id: 'EXP-890', category: 'Machine Maintenance', amount: 8500, vendor_name: 'Roland Tech Services', payment_method: 'UPI', expense_date: '2026-08-05', description: 'Eco-Solvent Print Head calibration and damper replacement' },
  { id: 'EXP-891', category: 'Electricity & Utilities', amount: 24500, vendor_name: 'Adani Electricity Mumbai', payment_method: 'Net Banking', expense_date: '2026-08-10', description: 'Factory & workshop power consumption July 2026' },
  { id: 'EXP-892', category: 'Delivery & Transport', amount: 3200, vendor_name: 'FastCargo Dispatch', payment_method: 'Cash', expense_date: '2026-08-12', description: 'Express delivery charges for MTDC exhibition backdrop' },
  { id: 'EXP-893', category: 'Packaging & Consumables', amount: 4800, vendor_name: 'Om Packaging House', payment_method: 'Cash', expense_date: '2026-08-13', description: 'Corrugated rolls, bubble wrap, edge protectors' }
];
writeCsv('expenses.csv', [
  'id', 'category', 'amount', 'vendor_name', 'payment_method', 'expense_date', 'description'
], sampleExpenses);

// 13. Production Tasks (Employee Work Allocation & Multi-Task Tracking)
const rawTasks = db.prepare("SELECT * FROM production_tasks ORDER BY task_date DESC, created_at DESC").all();
const productionTasks = rawTasks.map(t => ({
  task_id: t.id,
  task_date: t.task_date || '',
  employee_id: t.employee_id || '',
  employee_name: t.employee_name || '',
  order_id: t.order_id || '',
  order_number: t.order_number || '',
  customer_name: t.customer_name || '',
  process_name: t.process_name || '',
  quantity: t.quantity || 1,
  unit: t.unit || 'Nos',
  start_time: t.start_time || '',
  end_time: t.end_time || '',
  total_duration_minutes: t.total_duration_minutes || 0,
  status: t.status || 'Pending',
  priority: t.priority || 'Normal',
  machine_name: t.machine_name || '',
  department: t.department || 'Production',
  completed_qty: t.completed_qty || 0,
  rejected_qty: t.rejected_qty || 0,
  rework_qty: t.rework_qty || 0,
  qc_status: t.qc_status || 'Pending',
  created_by: t.created_by || '',
  completed_by: t.completed_by || '',
  completed_at: t.completed_at || ''
}));
writeCsv('production_tasks.csv', [
  'task_id', 'task_date', 'employee_id', 'employee_name', 'order_id', 'order_number',
  'customer_name', 'process_name', 'quantity', 'unit', 'start_time', 'end_time',
  'total_duration_minutes', 'status', 'priority', 'machine_name', 'department',
  'completed_qty', 'rejected_qty', 'rework_qty', 'qc_status', 'created_by', 'completed_by', 'completed_at'
], productionTasks);

// 14. Audit Logs (Order state transitions & user actions)
const auditLogs = (initialOrderAuditLogs || []).map(l => ({
  log_id: l.id,
  order_id: l.orderId || '',
  order_number: l.orderNumber || '',
  customer_name: l.customerName || '',
  action_type: l.actionType || '',
  action_title: l.actionTitle || '',
  actor: l.actor || '',
  role: l.role || '',
  reason: typeof l.reason === 'object' ? JSON.stringify(l.reason) : String(l.reason || '').replace(/[\r\n]+/g, ' '),
  changes_summary: typeof l.changesSummary === 'object' ? JSON.stringify(l.changesSummary) : String(l.changesSummary || '').replace(/[\r\n]+/g, ' '),
  created_at: l.createdAt || ''
}));
writeCsv('audit_logs.csv', [
  'log_id', 'order_id', 'order_number', 'customer_name', 'action_type',
  'action_title', 'actor', 'role', 'reason', 'changes_summary', 'created_at'
], auditLogs);

console.log('\n--- ALL 16 SAFE CSV EXPORTS GENERATED SUCCESSFULLY ---');
